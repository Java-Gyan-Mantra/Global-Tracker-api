package com.basant.nlw.global.api.exception;

public class WeatherException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2832485022202375249L;

	public WeatherException(String message) {
		super(message);
	}

}
